package extra.de.extra.pkg01.opcion.pkg2;

import Servicio.FraccionServicio;

/**
 *
 * @author Guillote
 */
public class ExtraDeExtra01Opcion2 {

    public static void main(String[] args) {
        
        FraccionServicio fs = new FraccionServicio();
        
        fs.ingresarNumeros();
        fs.Menu();
        
    }

}
